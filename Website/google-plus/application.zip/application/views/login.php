    <!-- Page Content -->
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class='col-md-10'>
                   <!-- <div class="text-center"><h3><span class="label label-default">Signup for Admission<?php// echo $title;?></span></h3></div>
                    </br>-->
                    <div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                        

                    <div class="text-danger">
                      <a href="<?php echo $authUrl; ?>">  <img src="<?Php echo ASSET_PATH ?>images/google-sign-in.png"> </a>
                    </div>





                        
                    </div>

                        <div class="col-md-4"></div>

                    </div>

                </div>

        </div>
            <!--IMPORTANT INSTRUCTION
            <div class="row">

                <div class="col-md-1"></div>
                <div class="col-md-11">
                    <div > <h3 div class="info">Important Instructions </h3></div>
                    <div class="text-info">
                        <ol>
                            <li>Once admit card is issued, <b>NO </b> change will be allowed in your particulars.</li>
                            <li>Use Internet Explorer (8.0) or its above versions or others browsers like Google Chrome , Firefox.</li>
                        </ol>
                    </div>
                    -->

        </div>
                </div>
            </div>
        </div>




