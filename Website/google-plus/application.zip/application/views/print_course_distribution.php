<?php
 //new PDF();
    $form = new CourseDistributionReport($cd,$dept_name,$program_name);
    //$form->printReport($lds,$dept_name,$cr_hrs,$max_marks);

?>
