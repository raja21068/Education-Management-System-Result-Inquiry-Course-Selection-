<?php
 //new PDF();
    $form = new AppFormReport($lds,$dept_name,$cr_hrs,$max_marks);
    //$form->printReport($lds,$dept_name,$cr_hrs,$max_marks);

?>
