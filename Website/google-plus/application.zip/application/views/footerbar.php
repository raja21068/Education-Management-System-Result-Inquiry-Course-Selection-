</div>
</div>
</div>
</div>
<!-- Footer / End -->


<!-- Footer Bottom / Start  -->
<footer id="footer-bottom">
		<!-- Copyrights -->
	
	<!-- 960 Container -->
	<div class="container">


		<!-- Menu -->
		<div class="eight columns" style="color: white">
			Copyright &copy; 2015, All Rights Reserved</a>
        </div>

	</div>

	<!-- 960 Container / End -->

</footer>
<!-- Footer Bottom / End -->


   <script>
      
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>

</body>
</html>