<?php
require_once('DataBaseManager1.php');
$link=DataBaseManager1::connect();

$roll_no=mysqli_real_escape_string($link,$_POST['roll_number']);
$name=mysqli_real_escape_string($link,$_POST['name']);
$fname=mysqli_real_escape_string($link,$_POST['fname']);
$surname=mysqli_real_escape_string($link,$_POST['surname']);
$semester=mysqli_real_escape_string($link,$_POST['semester']);
$shift=mysqli_real_escape_string($link,$_POST['shift']);
$dept_name=mysqli_real_escape_string($link,$_POST['dept_name']);
$challan_no=mysqli_real_escape_string($link,$_POST['challanNo']);
$challan_date=mysqli_real_escape_string($link,$_POST['challanDate']);
$challan_rs=mysqli_real_escape_string($link,$_POST['challanRS']);
$exam_type=mysqli_real_escape_string($link,$_POST['exam_type']);
$batch_id=mysqli_real_escape_string($link,$_POST['batch_id']);
$scheme_id=mysqli_real_escape_string($link,$_POST['scheme_id']);
$courseArray=$_POST['courceArray'];
if($challan_no="" || $challan_date=="" || $challan_rs==""){
    $challan_no=0;
    $challan_date='null';
    $challan_rs=0;
}

$form_sumbit_date=date("Y-m-d");
$year=date("Y");
//echo($exam_type."</BR>".$form_sumbit_date."</BR>".$batch_id."</BR>".$roll_no."</BR>".$challan_no."</BR>".$challan_date."</BR>".$challan_rs);
$lastid=DataBaseManager1::addExamFormData($exam_type,$form_sumbit_date,$batch_id,$roll_no,$challan_no,$challan_date,$challan_rs);

$length = count($courseArray);
for ($i = 0; $i < $length; $i++) {
    DataBaseManager1::addExamPapers($lastid,$semester,$scheme_id,$courseArray[$i]);
  //  print "</BR>".$courseArray[$i];
}


require('fpdf/cellpdf.php');
class PDF extends FPDF
{
    function Header()
    {
//    	$this->Image('sindh-university.png',50,50,100);

        //	$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size

        $this->SetFont('Arial','B',15);
        //  $this->Cell($w,9,$REMARKS_PROGRAM_NAME,1,1,'C',false);
//	$this->Ln(10);

    }
    function Footer()
    {
        //Position at 1.5 cm from bottom
        $this->SetY(-15);
        //Arial italic 8
        $this->SetFont('Arial','I',8);
        //Page number
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }

}
                $pdf=new CellPDF();
                $pdf->SetFont('Times','',12);
                $pdf->AddPage();


                //	$pdf->AddPage();
                $pdf->Image('images/logo.png',20,5,20);
                $pdf->SetFont('Times','',20);


                $pdf->Cell(0,8,"University of Sindh Jamshoro",0,1,'C',false);
                $pdf->Ln();
                $pdf->text(80,22,"Examination Form");
                $pdf->Ln();
                $pdf->Image('images/right_logo.jpg',170,5,18);
                    $pdf->SetFont('Times','',12);

                    $pdf->text(20,30,"REGULAR");
                    $pdf->text(100,6,"$lastid");

                $pdf->text(30,37,"Challan No: $challan_no");
                $pdf->text(80,37,"Challan Date: $challan_date");
                $pdf->text(160,37,"Challan Rs: $challan_rs");

                    $pdf->Line(20,40,200,40);


                       $pdf->SetFont('Times','',12);


//	$pdf->Cell(0,9,"Admission Resuls",0,1,'C',false);
//$pdf->Ln();
                $pdf->Ln();
                $w = array(90, 60, 120, 50,40,20);
                $h=8;

                $pdf->Cell($w[1],$h,"Department",1,0,'C');
                $pdf->Cell($w[1],$h,"$dept_name",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Roll No",1,0,'C');
                $pdf->Cell($w[1],$h,"$roll_no",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Name",1,0,'C');
                $pdf->Cell($w[1],$h,"$name",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Father's Name",1,0,'C');
                $pdf->Cell($w[1],$h,"$fname",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Surame",1,0,'C');
                $pdf->Cell($w[1],$h,"$surname",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Semester",1,0,'C');
                $pdf->Cell($w[1],$h,"$semester",1,0,'C');
                $pdf->Ln();
                $pdf->Cell($w[1],$h,"Examination Year",1,0,'C');
                $pdf->Cell($w[1],$h,"$year",1,0,'C');
                $pdf->Ln();
                $pdf->Image('images/Blank-person-photo.png',150,42,55);


$length = count($courseArray);
$count=0;
$pdf->ln();
$pdf->Cell(190,$h,"Subjects/Papers",1,0,'C');
$pdf->ln();
for ($i = 0; $i < $length; $i++) {
    $count++;
    $pdf->SetFont('Times','',10);
    $pdf->SetTextColor(0,0,255);
  //  $pdf->SetXY(140, $w);
    $pdf->Cell(5,$h,"".$count,1,0,'C');
    $pdf->Cell(90,$h,"".$courseArray[$i],1,0,'L');
    if($count%2==0){
        $pdf->Ln();
    }

   // DataBaseManager1::addExamPapers($lastid,$semester,$scheme_id,$courseArray[$i]);
    //  print "</BR>".$courseArray[$i];
}

                $pdf->Ln();
                $pdf->Output();




?>