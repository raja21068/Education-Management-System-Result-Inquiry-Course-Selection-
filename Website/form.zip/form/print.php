<?php

if (isset($_REQUEST['s'])) {
  require_once './DatabaseManager.php';
  $con=DatabaseManager::connect();
    $programType =mysqli_real_escape_string($con,  $_REQUEST['program_type']);
    $seatNo = mysqli_real_escape_string($con,$_REQUEST['s']);
    $admissionListDetailId =mysqli_real_escape_string($con, $_REQUEST['admission_list_detail_id']);
    $admission_session = mysqli_real_escape_string($con,$_REQUEST['admission_session']);
    
    $result = DatabaseManager::getCandidate($seatNo, $programType, $admissionListDetailId);
    if ($row = mysqli_fetch_array($result)) {
        $candidateId = $row['CANDIDATE_ID'];
        $name = $row['NAME'];
        $father = $row['FATHER'];
        $district = $row['DISTRICT'];
        $area = $row['AREA'];
        $degree = $row['DEGREE'];
        $ssc_obt = $row['SSC_OBTAINED'];
        $ssc_perc = $row['SSC_PERC'];
        $hsc_obt = $row['HSC_OBTAINED'];
        $hsc_perc = $row['HSC_PERC'];
        $grad_obt = $row['GRAD_OBTAINED'];
        $grad_perc = $row['GRAD_PERC'];
        $test_score = $row['TEST_SCORE'];
        $test_perc = $row['TEST_PERC'];
        $cpn = $row['CPN'];
        $campus = $row['CAMPUS'];
        $category = $row['CATEGORY'];
        $discipline = $row['DISCIPLINE'];
        $campusId = $row['CAMPUS_ID'];
        $choiceNo = $row['CHOICE_NO'];
        $objectionRemarks = $row['OBJECTION_REMARKS'];
        $deductionMarks = $row['DEDUCTION_MARKS'];
        $marksAfterDeduction = $row['MARKS_AFTER_DEDUCTION'];

		$ssc_total_marks = $row['SSC_TOTAL'];
		$hsc_total_marks = $row['HSC_TOTAL'];
		$ssc_year = $row['SSC_YEAR'];
		$hsc_year = $row['HSC_YEAR'];
	
		$degree = $row['DEGREE'];
		$last_issuer = $row['ISSUER'];
		$grd_total_marks = $row['GRD_TOTAL'];
		$grd_year = $row['GRD_YEAR'];

	


require('fpdf/cellpdf.php');
		class PDF extends FPDF
		{
		function Header()
			{
//    	$this->Image('sindh-university.png',50,50,100);
		   
		//	$this->SetFont( 'Arial', 'B', 18 ); //set font to Arial, Bold, and 16 Size 
			 
 $this->SetFont('Arial','B',15);
 //  $this->Cell($w,9,$REMARKS_PROGRAM_NAME,1,1,'C',false);
//	$this->Ln(10);
  		
		}
		function Footer()
{
    //Position at 1.5 cm from bottom
    $this->SetY(-15);
    //Arial italic 8
    $this->SetFont('Arial','I',8);
    //Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

		}
		$pdf=new CellPDF();
		$pdf->SetFont('Times','',12);
		$pdf->AddPage();
		

		
		//$pdf->Cell(0,8,"University of Sindh Jamshoro Admission Resuls",0,1,'C',false);
			$pdf->SetFont('Times','',20);
	//	$pdf->AddPage();
		$pdf->Image('images/logo.png',20,5,20);
		$pdf->Cell(0,8,"University of Sindh Jamshoro",0,1,'C',false);
		$pdf->Ln();
		$pdf->text(80,22,"Admission Results");
		$pdf->Ln();
		$pdf->Image('images/right_logo.jpg',170,5,18);
		$pdf->Line(10,30,200,30);
	
		$pdf->SetFont('Times','',12);
		
	//	$pdf->Cell(0,9,"Admission Resuls",0,1,'C',false);
		$pdf->Ln();
		$w = array(90, 45, 120, 50,40,20);
		$h=8;
		$pdf->Cell($w[1],$h,"Seat#",1,0,'C');
		$pdf->Cell($w[1],$h,"$seatNo",1,0,'C');
		$pdf->Ln();
		$pdf->Cell($w[1],$h,"Name",1,0,'C');
		$pdf->Cell($w[1],$h,"$name",1,0,'C');
		$pdf->Ln();
		
		$pdf->Cell($w[1],$h,"Father's Name:",1,0,'C');
		$pdf->Cell($w[1],$h,"$father",1,0,'C');
		$pdf->Ln();
		$pdf->Cell($w[1],$h,"District (Domicile):",1,0,'C');
		$pdf->Cell($w[1],$h,"$district",1,0,'C');
		$pdf->Ln();
				if ($area=="U" || $area=="0"){
		$pdf->Cell($w[1],$h,"Urban/Rural:",1,0,'C');
		$pdf->Cell($w[1],$h,"URBAN",1,0,'C');
		$pdf->Ln();

			}else{
		$pdf->Cell($w[1],$h,"Urban/Rural:",1,0,'C');
		$pdf->Cell($w[1],$h,"RURAL",1,0,'C');
		$pdf->Ln();

		}
		
		$pdf->Cell($w[1],$h,"SSC (Matric) Marks:",1,0,'C');
		$pdf->Cell($w[1],$h,$ssc_obt,1,0,'C');
		$pdf->Ln();
	
		
		$pdf->Cell($w[1],$h,"SSC Total Marks:",1,0,'C');
		$pdf->Cell($w[1],$h,$ssc_total_marks,1,0,'C');
		$pdf->Ln();
	
		$pdf->Cell($w[1],$h,"SSC Year:",1,0,'C');
		$pdf->Cell($w[1],$h,$ssc_year,1,0,'C');
		$pdf->Ln();
	
		
		
		$pdf->Cell($w[1],$h,"HSC (Inter) Marks:",1,0,'C');
		$pdf->Cell($w[1],$h,$hsc_obt,1,0,'C');
		$pdf->Ln();
	
		
		$pdf->Cell($w[1],$h,"HSC Total Marks:",1,0,'C');
		$pdf->Cell($w[1],$h,$hsc_total_marks,1,0,'C');
		$pdf->Ln();
	
		$pdf->Cell($w[1],$h,"HSC Year:",1,0,'C');
		$pdf->Cell($w[1],$h,$hsc_year,1,0,'C');
		$pdf->Ln();
	
		
		
		
		
		if($programType == 1){
		$pdf->Cell($w[1],$h,"HSC Group:",1,0,'C');
		$pdf->Cell($w[1],$h,$degree,1,0,'C');
		$pdf->Ln();
	

		}else{
		$pdf->Cell($w[1],$h,"Degree:",1,0,'C');
		$pdf->Cell($w[1],$h,$degree,1,0,'C');
		$pdf->Ln();
	

		}
		
		if($programType == 1){
		$pdf->Cell($w[1],$h,"HSC Board:",1,0,'C');
		$pdf->Cell($w[1],$h,$last_issuer,1,0,'C');
		$pdf->Ln();
	
				}
		$pdf->Cell($w[1],$h,"TEST MARKS:",1,0,'C');
		$pdf->Cell($w[1],$h,$test_score,1,0,'C');
		$pdf->Ln();
	
		$pdf->Cell($w[1],$h,"SSC (Matric) Score[10]:",1,0,'C');
		$pdf->Cell($w[1],$h,$ssc_perc,1,0,'C');
		$pdf->Ln();
		
	
			
			if($programType == 1){
		$pdf->Cell($w[1],$h,"HSC (Inter) Score[50]:",1,0,'C');
		$pdf->Cell($w[1],$h,$hsc_perc,1,0,'C');
		$pdf->Ln();

					}else{
					
		$pdf->Cell($w[1],$h,"HSC (Inter) Score[15]:",1,0,'C');
		$pdf->Cell($w[1],$h,$hsc_perc,1,0,'C');
		$pdf->Ln();
		}
			
			if($programType == 2){
		$pdf->Cell($w[1],$h,"Graduation:",1,0,'C');
		$pdf->Cell($w[1],$h,$degree,1,0,'C');
		$pdf->Ln();

		$pdf->Cell($w[1],$h,"Graduation marks:",1,0,'C');
		$pdf->Cell($w[1],$h,$grad_obt,1,0,'C');
		$pdf->Ln();
		
		$pdf->Cell($w[1],$h,"Graduation score[35]:",1,0,'C');
		$pdf->Cell($w[1],$h,$grad_perc,1,0,'C');
		$pdf->Ln();
		
		
			}
			
			if ($deductionMarks != 0) {
			
			$pdf->Cell($w[1],$h,"DEDUCTION MARKS:",1,0,'C');
			$pdf->Cell($w[1],$h,$deductionMarks,1,0,'C');
			$pdf->Ln();
		
			$pdf->Cell($w[1],$h,"MARKS AFTER DEDUCTION:",1,0,'C');
			$pdf->Cell($w[1],$h,$marksAfterDeduction,1,0,'C');
			$pdf->Ln();
				
			}
			
			$pdf->Cell($w[1],$h,"TEST SCORE [40]:",1,0,'C');
			$pdf->Cell($w[1],$h,$test_perc,1,0,'C');
			$pdf->Ln();
			
			$pdf->Cell($w[1],$h,"Total Score (CPN)[100]:",1,0,'C');
			$pdf->Cell($w[1],$h,$cpn,1,0,'C');
			$pdf->Ln();
			
			
			if ($objectionRemarks != "") {
			$pdf->Cell($w[1],$h,"Objection Remarks:",1,0,'C');
			$pdf->Cell($w[1],$h,$objectionRemarks,1,0,'C');
			$pdf->Ln();
			
			
			}
			
			if ($campus != "") {
				$pdf->SetFont('Times','B',12);
					$pdf->SetTextColor(255,0,0);
	//				$pdf->Cell($w[0],$h,"You are selected in:",1,0,'C');/
				//	$pdf->Ln();
	
				
				$pdf->Cell(0,8,"You are selected in: ",0,1,'L',false);
					$pdf->SetTextColor(0,0,0);
				
				$pdf->SetFont('Times','',11);
			$pdf->Cell($w[1],$h,"Program:",1,0,'C');
			$pdf->Cell($w[1],$h,$discipline,1,0,'C');
			$pdf->Ln();
			
			$pdf->Cell($w[1],$h,"Category:",1,0,'C');
			$pdf->Cell($w[1],$h,$category,1,0,'C');
			$pdf->Ln();
	
			$pdf->Cell($w[1],$h,"Campus:",1,0,'C');
			$pdf->Cell($w[1],$h,$campus,1,0,'C');
			$pdf->Ln();
			$pdf->Ln();
	
				   while ($row = mysqli_fetch_array($result)) {
                    $campus = $row['CAMPUS'];
                    $category = $row['CATEGORY'];
                    $discipline = $row['DISCIPLINE'];
                    $campusId2 = $row['CAMPUS_ID'];
			
			
			$pdf->Cell($w[1],$h,"Program:",1,0,'C');
			$pdf->Cell($w[1],$h,$discipline,1,0,'C');
			$pdf->Ln();
	
			$pdf->Cell($w[1],$h,"Category:",1,0,'C');
			$pdf->Cell($w[1],$h,$category,1,0,'C');
			$pdf->Ln();
					
					 //if ($campusId2 != $campusId) {
			$pdf->Cell($w[1],$h,"Campus:",1,0,'C');
			$pdf->Cell($w[1],$h,$campus,1,0,'C');
			$pdf->Ln();
			$pdf->Ln();
	
					
                    $campusId = $campusId2;
                    //} 
				}//end whhile
			
					}// end campus if
		if ($choiceNo != 1) {
//			$pdf->Cell(0,8," If any candidate wish to study in selected choice, he/she must deposit rs.200 in separate bank challan with application so that his/her choice may not be changed.",0,1,'L',false);				
		
		}else{
		//  $resultAdmi = DatabaseManager::getCandidateFromSession($seatNo, $programType, $admission_session);
		//  if ($resultAdmi) {
		//		 		$pdf->Cell(0,8,"YOU ARE SELECTED IN PREVIUOS MERIT LIST",0,1,'L',false);					
		//        } else {
		
	}	
		
		
		
		//$pdf->Ln();
		
		// ********************choices*****************************// 
		$choiceResult = DatabaseManager::getChoice($candidateId, $campusId);
				$campusUpper = "";
				 $i = 0;
            
                if ($i == 0) {
                    $i++;
    //              $pdf->Cell("80");
					$pdf->SetTextColor(255,0,0);
							$pdf->SetFont('Times','B',14);
						$pdf->SetXY(140, 36);
					$pdf->Cell($w[1],$h,"Your Choices",0,0,'C');
	
				 		//$pdf->Text(150,40,"Your Choices");
						$w=40;
						
					  	$pdf->SetTextColor(0,0,0);
				
       
                   }
				while ($choiceRow = mysqli_fetch_array($choiceResult)) {
							
					$shiftcampus = $choiceRow['SHIFT_NAME'];
					if($shiftcampus != $campusUpper){
					$w+=5;
							$pdf->SetFont('Times','',10);
							$pdf->SetTextColor(0,0,255);
							$pdf->SetXY(140, $w);
					$pdf->Cell($w[1],$h,"".$shiftcampus,0,0,'C');
					
							$pdf->SetTextColor(0,0,0);								
		
								$campusUpper = $shiftcampus;
					}
					$pdf->SetFont('Times','',10);

					$w+=6;
					$shiftId = $choiceRow['SHIFT_ID'];
                    $disc = $choiceRow['DISCIPLINE'];
                    $choice = $choiceRow['CHOICE_NO'];
					$pdf->SetXY(140, $w);
					$pdf->Cell($w[1],$h,"$choice- $disc",0,0,'L');
							
						 	
                }
		// ********************End choices*****************************// 
	
		
		}//get candidate if
		
	}	//request if
		$pdf->Ln();
		$pdf->Output();
	
       ?>
	   
	    	
		
			
	   			  
		
		
      



