<?php

/**
 * Created by PhpStorm.
 * User: RAJA DELL LAPTOP
 * Date: 9/5/2015
 * Time: 9:53 AM
 */
class DataBaseManager1
{
    public static  function connect(){
        $mysql_hostname = "localhost";

        $mysql_user = "root";
        $mysql_password = "";
        $mysql_database = "exam";
        $link = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) or die("<h2>Error connecting with database...!</h2>");
        return $link;

    }

    public static function getStudentInfo($rollNo){
        $link= DataBaseManager1::connect();
        $query_student="SELECT sr.`NAME`,sr.`FNAME`,sr.`SURNAME`,sr.`ROLL_NO`,
							prog.`PROGRAM_TITLE`,
							`scheme`.`YEAR`,`scheme`.`SCHEME_ID`,
							batch.BATCH_ID,batch.SHIFT,
							dept.`DEPT_NAME`
							FROM `student_registration` AS sr
							INNER JOIN `batch` ON sr.`BATCH_ID`=`batch`.`BATCH_ID`
							INNER JOIN `program` AS prog ON `batch`.`PROG_ID`=prog.`PROG_ID`
							INNER JOIN `department` AS dept ON prog.`DEPT_ID`=dept.`DEPT_ID`
							INNER JOIN `scheme`  ON prog.`PROG_ID`=`scheme`.`PROG_ID` AND prog.`DEPT_ID`=scheme.`DEPT_ID` AND `batch`.`YEAR`=`scheme`.`YEAR`
							WHERE ROLL_NO='$rollNo'";

        //                    echo($query_student."<br>");

        $result_student=mysqli_query($link,$query_student);
        return $result_student;


    }

  public static  function getCourceDetail($SCHEME_ID,$SEMESTER)
    {
        $link= DataBaseManager1::connect();
        $query="SELECT COURSE_NO,COURSE_TITLE FROM  scheme_detail WHERE  SCHEME_ID=$SCHEME_ID AND  SEMESTER =$SEMESTER";
        return $subject_query=mysqli_query($link,$query);

    }

    public static  function addExamFormData($exam_type,$date_of_sumbit,$batch_id,$roll_no,$challan_no=0,$challan_date='NULL',$challan_rs=0){
        $link= DataBaseManager1::connect();
        $query="INSERT INTO exam_form_student_enlorment (`EXAM_TYPE`, `DATE_OF_SUMBIT_FORM`, `student_registration_BATCH_ID`, `student_registration_ROLL_NO`, `CHALLAN_NO`, `CHALLAN_DATE`, `CHALLAN_RS`) VALUES ('$exam_type',$date_of_sumbit, $batch_id, '$roll_no',$challan_no, $challan_date, $challan_rs)";
        //echo($query);
        mysqli_query($link, $query);

        $last_id = mysqli_insert_id($link);
        return $last_id;


    }
    public static function addExamPapers($exam_form_id,$semester,$scheme_id,$course_no){
        $link= DataBaseManager1::connect();
        $query="INSERT INTO exam_form_paper (scheme_detail_SEMESTER,scheme_detail_SCHEME_ID,scheme_detail_COURSE_NO,exam_form_student_enlorment_ID) VALUES ($semester,$scheme_id, '$course_no',$exam_form_id)";
    //        echo($query."</br>");

        mysqli_query($link, $query);




    }


}



?>