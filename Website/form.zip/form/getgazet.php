
<?php
		require_once('DataBaseManager1.php');
		$link=DatabaseManager1::connect();

			$rollNo=mysqli_real_escape_string($link,$_REQUEST['rollNo']);
			$semester=mysqli_real_escape_string($link,$_REQUEST['semester']);
					   ?>
<form action="printExamForm.php" method="post">
					<?php

						$count=0;
					$result_student=DatabaseManager1::getStudentInfo($rollNo);

					echo("<table class='table  table-bordered table-striped'> ");

					while($row_student=mysqli_fetch_array($result_student)){
       						$name=$row_student['NAME'];
							$fname=$row_student['FNAME'];
							$surname=$row_student['SURNAME'];
							$roll_no=$row_student['ROLL_NO'];
							$exam_year=$row_student['YEAR'];
							$scheme_id=$row_student['SCHEME_ID'];
							$batch_id=$row_student['BATCH_ID'];
							$shift=$row_student['SHIFT'];
							$dept_name=$row_student['DEPT_NAME'];
?>


	<?php

						echo('<input type="hidden" name="roll_number" value='.$roll_no.'>');
						echo('<input type="hidden" name="name" value="'.$name.'">');
						echo('<input type="hidden" name="fname" value="'.$fname.'">');
						echo('<input type="hidden" name="surname" value="'.$surname.'">');
						echo('<input type="hidden" name="semester" value='.$semester.'>');
						echo('<input type="hidden" name="shift" value="'.$shift.'"">');
						echo('<input type="hidden" name="dept_name" value="'.$dept_name.'"">');
						echo('<input type="hidden" name="batch_id" value='.$batch_id.'>');
						echo('<input type="hidden" name="scheme_id" value='.$scheme_id.'>');
						//echo('<input type="hidden" name="" value="">');
						//echo('<input type="hidden" name="" value="">');


						echo("<TR>");
						echo("<Td>ROLL NO:</Td>");
						echo("<Td>$rollNo</Td>");
						echo("</TR>");
						echo("<TR>");
						echo("<Td>Name</Td>");
						echo("<Td>$name</Td>");
						echo("</TR>");
						
						echo("<TR>");
						echo("<Td>Father<span>'<span>s Name</Td>");
						echo("<Td>$fname</Td>");
						echo("</TR>");
						
						echo("<TR>");
						echo("<Td>Surname</Td>");
						echo("<Td>$surname</Td>");
						echo("</TR>");

						echo("<TR>");
						echo("<Td COLSPAN='2'><input type='radio' name='exam_type' value='F'>FAILURE  <input type='radio' name='exam_type' value='I'>IMPROVER  <input type='radio' name='exam_type' value='R' checked='checked'>REGULAR  </Td>");
						echo("</TR>");

						echo("<TR>");
						echo("<Td>Challan No</Td>");
						echo("<Td><input type='number' name='challanNo'></Td>");
						echo("</TR>");

						echo("<TR>");
						echo("<Td>Challan Date</Td>");
						echo("<Td><input type='date' name='challanDate'></Td>");
						echo("</TR>");

						echo("<TR>");
						echo("<Td>Challan Rs</Td>");
						echo("<Td><input type='number' name='challanRS'></Td>");
						echo("</TR>");





						echo("<TR>");
						echo("<td><select name='courceDetail' id='courceDetail'>");

						$subject_query=	DataBaseManager1::getCourceDetail($scheme_id,$semester);
						while($row_subject=mysqli_fetch_array($subject_query)){
							$COURSE_NO=$row_subject['COURSE_NO'];
							$COURSE_TITLE=$row_subject['COURSE_TITLE'];
							echo("<option value=$COURSE_NO>$COURSE_TITLE</option>");
						}

						echo("</<select > </td>");
						echo("<Td><button type='button' id='add-cources' >ADD SUBJECTS</input></Td>");

						echo("</TR>");
	// 	getGazet($rollNo,$name, $link);
	  }


					echo("	</select> ");

					echo("<div id='display'></div>");

					echo("</TABLE>");
					?>

<table class='table  table-bordered table-striped''>
	<tbody id="table-body-courceDetail" >
	</tbody>
	<tr><td colspan="3"><input type="submit" value="save and print"></td></tr>

</table>

</form>
<?php
				echo("</DIV>");
				echo("</DIV>");


						?>
<script type="text/javascript" src="jquery.min.js"></script>
<script>

	$("#add-cources").click(function(){
		var id = $("#courceDetail").val();
		var txt = $("#courceDetail option:selected").text();
		addDataInTable(id,txt);
	});

	function addDataInTable(id,txt){
		var len = ($("#table-body-courceDetail tr").length)+1;
		$("#table-body-courceDetail").append("<tr id='"+id+"'><td>"+len+"</td><input type='hidden' name='courceArray[]' value='"+txt+"'><td>"+txt+"</td><td><input type='button' onclick=\"deleteDataInTable('"+id+"','"+txt+"');\" value='X' ></td></tr>");
		$("#courceDetail option[value='"+id+"']").remove();
		//$("#my-div").append("");
		// for fix students
		/*
		 var choiceLen = $("#student_id option").length;
		 if(len >= 3 || choiceLen == 0){
		 $("#add-student").attr('disabled','disabled');
		 $("#add-student").removeClass('btn-default');
		 }
		 */

	}

	function deleteDataInTable(elementNo,txt){
		//alert("aaa");
		//$(elementNo).parent().parent().remove();

		$("#table-body-courceDetail tr[id='"+elementNo+"']").remove();
		$("#courceDetail").prepend("<option value=\""+elementNo+"\" >"+txt+"</option>");
		$("#table-body-courceDetail tr").each(function(index,elem){
			var no = (index +1);
			var d = $(elem).children().get(0);
			$(d).html(no);

		});

	}

</script>