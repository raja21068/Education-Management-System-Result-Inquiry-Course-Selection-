
<?php
echo ("<h2> $msg</h2>");
?>